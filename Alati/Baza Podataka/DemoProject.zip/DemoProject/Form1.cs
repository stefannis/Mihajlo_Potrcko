using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.Common;
using CodeEngine.Framework.QueryBuilder;
using CodeEngine.Framework.QueryBuilder.Enums;

namespace DemoProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void searchOldSchoolButton_Click(object sender, EventArgs e)
        {
            int maxRecords = 10;
            string statement = "SELECT TOP " + maxRecords + " * FROM Customers ";
            string whereConcatenator = "WHERE ";

            if (companyNameTextBox.Text.Length > 0) 
            {
	            statement += whereConcatenator;
	            statement += "CompanyName like '" + companyNameTextBox.Text + "%' ";
	            whereConcatenator = "AND ";
            }
            if (cityTextBox.Text.Length > 0)
            {
	            statement += whereConcatenator;
	            statement += "City like '" + cityTextBox.Text + "%' ";
	            whereConcatenator = "AND ";
            }
            if (countryComboBox.SelectedItem != null)
            {
                statement += whereConcatenator;
                statement += "Country = '" + countryComboBox.SelectedItem + "' ";
	            whereConcatenator = "AND ";
            }

            MessageBox.Show(statement, "Old-school query");
        }

        private void searchNewWayButton_Click(object sender, EventArgs e)
        {
            int maxRecords = 10;
            SelectQueryBuilder query = new SelectQueryBuilder();
            query.SelectFromTable("Customers");
            query.SelectAllColumns();
            query.TopRecords = maxRecords;

            if (companyNameTextBox.Text.Length > 0)
                query.AddWhere("CompanyName", Comparison.Like, companyNameTextBox.Text + "%");

            if (cityTextBox.Text.Length > 0)
                query.AddWhere("City", Comparison.Like, cityTextBox.Text + "%");

            if (countryComboBox.SelectedItem != null)
                query.AddWhere("Country", Comparison.Equals, countryComboBox.SelectedItem);

            string statement = string.Format(
                "Query built by BuildQuery:\n\n{0}",
                query.BuildQuery());

            MessageBox.Show(statement, "BuildQuery()");

            // or, have a DbCommand object built for even more safety against SQL Injection attacks:
            query.SetDbProviderFactory(DbProviderFactories.GetFactory("System.Data.SqlClient"));
            DbCommand command = query.BuildCommand();

            statement = string.Format(
                "Query built by BuildCommand (not showing parameter values):\n\n{0}",
                command.CommandText);

            MessageBox.Show(statement, "BuildCommand()");
        }

        private void trySQLInjectionAttackButton_Click(object sender, EventArgs e)
        {
            // Put SQL injection attack data in the customer textbox
            companyNameTextBox.Text = "'; SELECT * FROM sysobjects --";
            MessageBox.Show("The Company name TextBox has been filled with a SQL Injection attack.\nCompare the different built-up statements by pushing the search buttons");
        }

        private void createJoinQueryButton_Click(object sender, EventArgs e)
        {
            SelectQueryBuilder query = new SelectQueryBuilder();
            query.SelectFromTable("Orders");

            query.AddJoin(JoinType.InnerJoin,
                          "Customers", "CustomerID",
                          Comparison.Equals,
                          "Orders", "CustomerID");

            query.AddWhere("Customers.City", Comparison.Equals, "London");

            MessageBox.Show(query.BuildQuery(), "Join query");
        }

        private void createCountQueryButton_Click(object sender, EventArgs e)
        {
            SelectQueryBuilder query = new SelectQueryBuilder();
            query.SelectColumns("count(*) AS Count", "ShipCity");
            query.SelectFromTable("Orders");
            query.GroupBy("ShipCity");
            query.AddHaving("ShipCity", Comparison.NotEquals, "Amsterdam");
            query.AddOrderBy("count(*)", Sorting.Descending);

            MessageBox.Show(query.BuildQuery(), "Count query");
        }

        private void buildComplexWhereButton_Click(object sender, EventArgs e)
        {
            SelectQueryBuilder query = new SelectQueryBuilder();
            query.SelectFromTable("Orders");

            // Add 'Criteria' column to level 1
            query.AddWhere("CustomerID", Comparison.Equals, "VINET", 1);
            query.AddWhere("OrderDate", Comparison.LessThan, new DateTime(2005, 1, 1), 1);

            // Add first 'Or...' column to level 2
            query.AddWhere("CustomerID", Comparison.Equals, "TOMSP", 2);
            query.AddWhere("OrderDate", Comparison.LessThan, new DateTime(2004, 6, 30), 2);

            // Add second 'Or...' column to level 3
            query.AddWhere("CustomerID", Comparison.Equals, "TOMSP", 3);
            query.AddWhere("OrderDate", Comparison.GreaterThan, new DateTime(2006, 1, 1), 3);

            MessageBox.Show(query.BuildQuery(), "Complex where");
        }

        private void createComplexWhere2Button_Click(object sender, EventArgs e)
        {
            SelectQueryBuilder query = new SelectQueryBuilder();
            query.SelectFromTable("Orders");

            // Add 'Criteria' column to level 1
            query.AddWhere("CustomerID", Comparison.Equals, "VINET", 1);
            query.AddWhere("OrderDate", Comparison.LessThan, new DateTime(2005, 1, 1), 1);

            // Add 'Or...' column to level 2
            query.AddWhere("CustomerID", Comparison.Equals, "TOMSP", 2);

            // Add the date selection clause
            WhereClause clause =
                query.AddWhere("OrderDate", Comparison.LessThan, new DateTime(2004, 6, 30), 2);

            // Add a nested clause to the captured clause
            clause.AddClause(LogicOperator.Or, Comparison.GreaterThan, new DateTime(2006, 1, 1));

            MessageBox.Show(query.BuildQuery(), "Complex where with nested clause");
        }

        private void createQueryWithSqlLiteralButton_Click(object sender, EventArgs e)
        {
            SelectQueryBuilder query = new SelectQueryBuilder();
            query.SelectFromTable("Orders");
            query.AddWhere("OrderDate", Comparison.LessOrEquals, "getDate()");

            MessageBox.Show("Without SqlLiteral:\n\n" + query.BuildQuery(), "Without SqlLiteral");
            
            query = new SelectQueryBuilder();
            query.SelectFromTable("Orders");
            query.AddWhere("OrderDate", Comparison.LessOrEquals, new SqlLiteral("getDate()"));

            MessageBox.Show("With SqlLiteral:\n\n" + query.BuildQuery(), "With SqlLiteral");
        }
    }
}