namespace DemoProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.companyNameTextBox = new System.Windows.Forms.TextBox();
            this.cityLabel = new System.Windows.Forms.Label();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.countryComboBox = new System.Windows.Forms.ComboBox();
            this.countryLabel = new System.Windows.Forms.Label();
            this.trySQLInjectionAttackButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.createJoinQueryButton = new System.Windows.Forms.Button();
            this.createCountQueryButton = new System.Windows.Forms.Button();
            this.buildComplexWhereButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.createComplexWhere2Button = new System.Windows.Forms.Button();
            this.createQueryWithSqlLiteralButton = new System.Windows.Forms.Button();
            this.searchNewWayButton = new System.Windows.Forms.Button();
            this.searchOldSchoolButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Company name:";
            // 
            // companyNameTextBox
            // 
            this.companyNameTextBox.Location = new System.Drawing.Point(116, 17);
            this.companyNameTextBox.Name = "companyNameTextBox";
            this.companyNameTextBox.Size = new System.Drawing.Size(171, 20);
            this.companyNameTextBox.TabIndex = 1;
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Location = new System.Drawing.Point(9, 44);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(27, 13);
            this.cityLabel.TabIndex = 2;
            this.cityLabel.Text = "City:";
            // 
            // cityTextBox
            // 
            this.cityTextBox.Location = new System.Drawing.Point(116, 41);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(171, 20);
            this.cityTextBox.TabIndex = 3;
            // 
            // countryComboBox
            // 
            this.countryComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.countryComboBox.FormattingEnabled = true;
            this.countryComboBox.Items.AddRange(new object[] {
            "Argentina",
            "Austria",
            "Belgium",
            "Brazil",
            "Canada",
            "Denmark",
            "Finland",
            "France",
            "Germany",
            "Ireland",
            "Italy",
            "Mexico",
            "Norway",
            "Poland",
            "Portugal",
            "Spain",
            "Sweden",
            "Switzerland",
            "UK",
            "USA",
            "Venezuela"});
            this.countryComboBox.Location = new System.Drawing.Point(116, 65);
            this.countryComboBox.Name = "countryComboBox";
            this.countryComboBox.Size = new System.Drawing.Size(171, 21);
            this.countryComboBox.TabIndex = 4;
            // 
            // countryLabel
            // 
            this.countryLabel.AutoSize = true;
            this.countryLabel.Location = new System.Drawing.Point(9, 70);
            this.countryLabel.Name = "countryLabel";
            this.countryLabel.Size = new System.Drawing.Size(46, 13);
            this.countryLabel.TabIndex = 5;
            this.countryLabel.Text = "Country:";
            // 
            // trySQLInjectionAttackButton
            // 
            this.trySQLInjectionAttackButton.Location = new System.Drawing.Point(12, 104);
            this.trySQLInjectionAttackButton.Name = "trySQLInjectionAttackButton";
            this.trySQLInjectionAttackButton.Size = new System.Drawing.Size(275, 21);
            this.trySQLInjectionAttackButton.TabIndex = 8;
            this.trySQLInjectionAttackButton.Text = "Try SQL Injection attack";
            this.trySQLInjectionAttackButton.UseVisualStyleBackColor = true;
            this.trySQLInjectionAttackButton.Click += new System.EventHandler(this.trySQLInjectionAttackButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.createQueryWithSqlLiteralButton);
            this.groupBox2.Controls.Add(this.createComplexWhere2Button);
            this.groupBox2.Controls.Add(this.buildComplexWhereButton);
            this.groupBox2.Controls.Add(this.createCountQueryButton);
            this.groupBox2.Controls.Add(this.createJoinQueryButton);
            this.groupBox2.Location = new System.Drawing.Point(12, 202);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(299, 113);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Other examples";
            // 
            // createJoinQueryButton
            // 
            this.createJoinQueryButton.Location = new System.Drawing.Point(11, 19);
            this.createJoinQueryButton.Name = "createJoinQueryButton";
            this.createJoinQueryButton.Size = new System.Drawing.Size(137, 23);
            this.createJoinQueryButton.TabIndex = 0;
            this.createJoinQueryButton.Text = "Join query";
            this.createJoinQueryButton.UseVisualStyleBackColor = true;
            this.createJoinQueryButton.Click += new System.EventHandler(this.createJoinQueryButton_Click);
            // 
            // createCountQueryButton
            // 
            this.createCountQueryButton.Location = new System.Drawing.Point(154, 19);
            this.createCountQueryButton.Name = "createCountQueryButton";
            this.createCountQueryButton.Size = new System.Drawing.Size(133, 23);
            this.createCountQueryButton.TabIndex = 1;
            this.createCountQueryButton.Text = "Count query";
            this.createCountQueryButton.UseVisualStyleBackColor = true;
            this.createCountQueryButton.Click += new System.EventHandler(this.createCountQueryButton_Click);
            // 
            // buildComplexWhereButton
            // 
            this.buildComplexWhereButton.Location = new System.Drawing.Point(11, 49);
            this.buildComplexWhereButton.Name = "buildComplexWhereButton";
            this.buildComplexWhereButton.Size = new System.Drawing.Size(137, 23);
            this.buildComplexWhereButton.TabIndex = 2;
            this.buildComplexWhereButton.Text = "Complex Where";
            this.buildComplexWhereButton.UseVisualStyleBackColor = true;
            this.buildComplexWhereButton.Click += new System.EventHandler(this.buildComplexWhereButton_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.searchOldSchoolButton);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.searchNewWayButton);
            this.groupBox3.Controls.Add(this.trySQLInjectionAttackButton);
            this.groupBox3.Controls.Add(this.cityTextBox);
            this.groupBox3.Controls.Add(this.countryLabel);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.countryComboBox);
            this.groupBox3.Controls.Add(this.companyNameTextBox);
            this.groupBox3.Controls.Add(this.cityLabel);
            this.groupBox3.Location = new System.Drawing.Point(12, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(299, 194);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Search Example";
            // 
            // createComplexWhere2Button
            // 
            this.createComplexWhere2Button.Location = new System.Drawing.Point(154, 48);
            this.createComplexWhere2Button.Name = "createComplexWhere2Button";
            this.createComplexWhere2Button.Size = new System.Drawing.Size(133, 23);
            this.createComplexWhere2Button.TabIndex = 3;
            this.createComplexWhere2Button.Text = "Complex Where 2";
            this.createComplexWhere2Button.UseVisualStyleBackColor = true;
            this.createComplexWhere2Button.Click += new System.EventHandler(this.createComplexWhere2Button_Click);
            // 
            // createQueryWithSqlLiteralButton
            // 
            this.createQueryWithSqlLiteralButton.Location = new System.Drawing.Point(11, 79);
            this.createQueryWithSqlLiteralButton.Name = "createQueryWithSqlLiteralButton";
            this.createQueryWithSqlLiteralButton.Size = new System.Drawing.Size(137, 23);
            this.createQueryWithSqlLiteralButton.TabIndex = 4;
            this.createQueryWithSqlLiteralButton.Text = "SqlLiteral";
            this.createQueryWithSqlLiteralButton.UseVisualStyleBackColor = true;
            this.createQueryWithSqlLiteralButton.Click += new System.EventHandler(this.createQueryWithSqlLiteralButton_Click);
            // 
            // searchNewWayButton
            // 
            this.searchNewWayButton.Location = new System.Drawing.Point(154, 157);
            this.searchNewWayButton.Name = "searchNewWayButton";
            this.searchNewWayButton.Size = new System.Drawing.Size(133, 23);
            this.searchNewWayButton.TabIndex = 7;
            this.searchNewWayButton.Text = "SelectQueryBuilder way";
            this.searchNewWayButton.UseVisualStyleBackColor = true;
            this.searchNewWayButton.Click += new System.EventHandler(this.searchNewWayButton_Click);
            // 
            // searchOldSchoolButton
            // 
            this.searchOldSchoolButton.Location = new System.Drawing.Point(11, 157);
            this.searchOldSchoolButton.Name = "searchOldSchoolButton";
            this.searchOldSchoolButton.Size = new System.Drawing.Size(137, 23);
            this.searchOldSchoolButton.TabIndex = 6;
            this.searchOldSchoolButton.Text = "Old-school way";
            this.searchOldSchoolButton.UseVisualStyleBackColor = true;
            this.searchOldSchoolButton.Click += new System.EventHandler(this.searchOldSchoolButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Build search query:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 326);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Name = "Form1";
            this.Text = "SelectQueryBuilder Examples";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox companyNameTextBox;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.ComboBox countryComboBox;
        private System.Windows.Forms.Label countryLabel;
        private System.Windows.Forms.Button trySQLInjectionAttackButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button createJoinQueryButton;
        private System.Windows.Forms.Button createCountQueryButton;
        private System.Windows.Forms.Button buildComplexWhereButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button createComplexWhere2Button;
        private System.Windows.Forms.Button createQueryWithSqlLiteralButton;
        private System.Windows.Forms.Button searchOldSchoolButton;
        private System.Windows.Forms.Button searchNewWayButton;
        private System.Windows.Forms.Label label2;
    }
}

