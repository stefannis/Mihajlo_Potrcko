
This Zip file contains a demo project which demonstrates the basics 
when using the SelectQueryBuilder class. Just unpack it to somewhere,
open the solution (in Visual Studio 2005) and play around with it!

If you are interested in the UpdateQueryBuilder, InsertQueryBuilder 
and DeleteQueryBuilder I have developed, you can download the 
complete CodeEngine Framework DLL at http://www.code-engine.com/

Have fun!

Ewout Stortenbeker

Email: 4ewout@gmail.com
For Framework and C# DAL code generator see: http://www.code-engine.com/